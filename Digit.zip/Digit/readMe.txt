Hello! This is a basic java code that can turn letters into larger letters comprised of “#” symbols.

Note: This code has multiple known bugs.

Usage: When typing in letters, make sure you use capital letters. Also, symbols and numbers are not compatible and will give you errors. These are easy fixes if you would like to edit the code yourself. I am busy with other projects and any code on my site can always be improved.

How to run: Digit.class is your executable file. Let.class is a class used with Digit.class so make sure that all of these files are in the same directory when run. If you want to edit these, open the .java files in any text editor. Make sure you recompile the .java files if you do make changes.

Any Questions? 
Email me at: jcutting164@gmail.com

