import java.util.*;
import java.lang.*;
public class Let{
  public Let(){
  }

  public ArrayList<String> A(){
    ArrayList<String> A = new ArrayList<String>();
    A.add("     #     ");
    A.add("    # #    ");
    A.add("   # # #   ");
    A.add("  #     #  ");
    A.add(" #       # ");
    return A;
  }

  public ArrayList<String> B(){
    ArrayList<String> B = new ArrayList<String>();
    B.add(" #######  ");
    B.add(" #      # ");
    B.add(" #######  ");
    B.add(" #      # ");
    B.add(" #######  ");
    return B;
  }
  public ArrayList<String> C(){
    ArrayList<String> C = new ArrayList<String>();
    C.add("  #### ");
    C.add(" #     ");
    C.add(" #     ");
    C.add(" #     ");
    C.add("  #### ");
    return C;
  }
  public ArrayList<String> D(){
    ArrayList<String> D = new ArrayList<String>();
    D.add(" ########   ");
    D.add("  #       # ");
    D.add("  #       # ");
    D.add("  #       # ");
    D.add("  ######    ");
    return D;
  }
  public ArrayList<String> E(){
    ArrayList<String> E = new ArrayList<String>();
    E.add(" #########  ");
    E.add(" #          ");
    E.add(" #########  ");
    E.add(" #          ");
    E.add(" ########## ");
    return E;
  }
  public ArrayList<String> F(){
    ArrayList<String> F = new ArrayList<String>();
    F.add(" ########## ");
    F.add(" #          ");
    F.add(" ######     ");
    F.add(" #          ");
    F.add(" #          ");
    return F;
  }
  public ArrayList<String> G(){
    ArrayList<String> G = new ArrayList<String>();
    G.add("    #### ");
    G.add("   #     ");
    G.add("  #  ### ");
    G.add(" #    #  ");
    G.add(" ####### ");
    return G;
  }
  public ArrayList<String> H(){
    ArrayList<String> H = new ArrayList<String>();
    H.add(" #        #  ");
    H.add(" #        #  ");
    H.add(" ##########  ");
    H.add(" #        #  ");
    H.add(" #        #  ");
    return H;
  }
  public ArrayList<String> I(){
    ArrayList<String> I = new ArrayList<String>();
    I.add(" ############ ");
    I.add("       #      ");
    I.add("       #      ");
    I.add("       #      ");
    I.add(" ############ ");
    return I;
  }
  public ArrayList<String> J(){
    ArrayList<String> J = new ArrayList<String>();
    J.add(" ########### ");
    J.add("       #     ");
    J.add("       #     ");
    J.add("   #   #     ");
    J.add("     ##      ");
    return J;
  }
  public ArrayList<String> K(){
    ArrayList<String> K = new ArrayList<String>();
    K.add(" #   #   ");
    K.add(" # #     ");
    K.add(" # #     ");
    K.add(" #   #   ");
    K.add(" #     # ");
    return K;
  }
  public ArrayList<String> L(){
    ArrayList<String> L = new ArrayList<String>();
    L.add(" #        ");
    L.add(" #        ");
    L.add(" #        ");
    L.add(" #        ");
    L.add(" ######## ");
    return L;
  }
  public ArrayList<String> M(){
    ArrayList<String> M = new ArrayList<String>();
    M.add(" #           # ");
    M.add(" # #       # # ");
    M.add(" #  #     #  # ");
    M.add(" #    #  #   # ");
    M.add(" #     #     # ");
    return M;
  }
  public ArrayList<String> N(){
    ArrayList<String> N = new ArrayList<String>();
    N.add(" #       # ");
    N.add(" # #     # ");
    N.add(" #  #    # ");
    N.add(" #   #   # ");
    N.add(" #      #  ");
    return N;
  }
  public ArrayList<String> O(){
    ArrayList<String> O = new ArrayList<String>();
    O.add("    ###    ");
    O.add("  #     #  ");
    O.add(" #       # ");
    O.add(" #       # ");
    O.add("    # #    ");
    return O;
  }
  public ArrayList<String> P(){
    ArrayList<String> P = new ArrayList<String>();
    P.add(" ######  ");
    P.add(" #     # ");
    P.add(" ####### ");
    P.add(" #       ");
    P.add(" #       ");
    return P;
  }
  public ArrayList<String> Q(){
    ArrayList<String> Q = new ArrayList<String>();
    Q.add("   # # #    ");
    Q.add("  #     #   ");
    Q.add(" #     # #  ");
    Q.add("  # # #   # ");
    Q.add("            ");
    return Q;
  }
  public ArrayList<String> R(){
    ArrayList<String> R = new ArrayList<String>();
    R.add(" ######  ");
    R.add(" #     # ");
    R.add(" # # # # ");
    R.add(" #   #   ");
    R.add(" #     # ");
    return R;
  }
  public ArrayList<String> S(){
    ArrayList<String> S = new ArrayList<String>();
    S.add("    ##### ");
    S.add("    #     ");
    S.add(" #   #    ");
    S.add("  #   #   ");
    S.add("    ##### ");
    return S;
  }
  public ArrayList<String> T(){
    ArrayList<String> T = new ArrayList<String>();
    T.add(" ######### ");
    T.add("     #     ");
    T.add("     #     ");
    T.add("     #     ");
    T.add("     #     ");
    return T;
  }
  public ArrayList<String> U(){
    ArrayList<String> U = new ArrayList<String>();
    U.add(" #        # ");
    U.add(" #        # ");
    U.add(" #        # ");
    U.add("  #      #  ");
    U.add("    ####    ");
    return U;
  }
  public ArrayList<String> V(){
    ArrayList<String> V = new ArrayList<String>();
    V.add(" #       # ");
    V.add("  #     #  ");
    V.add("   #   #   ");
    V.add("    # #    ");
    V.add("     #     ");
    return V;
  }
  public ArrayList<String> W(){
    ArrayList<String> W = new ArrayList<String>();
    W.add(" #       #       # ");
    W.add("  #     # #     #  ");
    W.add("   #   #   #   #   ");
    W.add("    # #     # #    ");
    W.add("     #       #     ");
    return W;
  }
  public ArrayList<String> X(){
    ArrayList<String> X = new ArrayList<String>();
    X.add(" #    # ");
    X.add("  #  #  ");
    X.add("   #    ");
    X.add("  # #   ");
    X.add(" #   #  ");
    return X;
  }
  public ArrayList<String> Y(){
    ArrayList<String> Y = new ArrayList<String>();
    Y.add(" #   # ");
    Y.add("  # #  ");
    Y.add("   #   ");
    Y.add("   #   ");
    Y.add("   #   ");
    return Y;
  }
  public ArrayList<String> Z(){
    ArrayList<String> Z = new ArrayList<String>();
    Z.add(" ####### ");
    Z.add("      #  ");
    Z.add("     #   ");
    Z.add("    #    ");
    Z.add("   ##### ");
    return Z;
  }

  public ArrayList<String> Response(){
    Scanner scan = new Scanner(System.in);
    String input = scan.nextLine();
    String[] inputBit = input.split("");
    ArrayList<String> tempList = new ArrayList<String>(Arrays.asList(inputBit));
    return tempList;
  }
  public HashMap<String, Integer> letNumTrans(){
    HashMap<String, Integer> NumTrans = new HashMap<String, Integer>();
    NumTrans.put("A", 0);
    NumTrans.put("B", 1);
    NumTrans.put("C", 2);
    NumTrans.put("D", 3);
    NumTrans.put("E", 4);
    NumTrans.put("F", 5);
    NumTrans.put("G", 6);
    NumTrans.put("H", 7);
    NumTrans.put("I", 8);
    NumTrans.put("J", 9);
    NumTrans.put("K", 10);
    NumTrans.put("L", 11);
    NumTrans.put("M", 12);
    NumTrans.put("N", 13);
    NumTrans.put("O", 14);
    NumTrans.put("P", 15);
    NumTrans.put("Q", 16);
    NumTrans.put("R", 17);
    NumTrans.put("S", 18);
    NumTrans.put("T", 19);
    NumTrans.put("U", 20);
    NumTrans.put("V", 21);
    NumTrans.put("W", 22);
    NumTrans.put("X", 23);
    NumTrans.put("Y", 24);
    NumTrans.put("Z", 25);
    return NumTrans;
  }
  public HashMap<Integer, ArrayList<String>> getLetMap(ArrayList<String> A,ArrayList<String> B,ArrayList<String> C,ArrayList<String> D,ArrayList<String> E,ArrayList<String> F,ArrayList<String> G,ArrayList<String> H,ArrayList<String> I,ArrayList<String> J
  ,ArrayList<String> K,ArrayList<String> L,ArrayList<String> M,ArrayList<String> N,ArrayList<String> O,ArrayList<String> P,ArrayList<String> Q,ArrayList<String> R,ArrayList<String> S,ArrayList<String> T,ArrayList<String> U,ArrayList<String> V,ArrayList<String> W,ArrayList<String> X
  ,ArrayList<String> Y,ArrayList<String> Z){

    HashMap<Integer, ArrayList<String>> letMap = new HashMap<Integer, ArrayList<String>>();
    letMap.put(0, A);
    letMap.put(1, B);
    letMap.put(2, C);
    letMap.put(3, D);
    letMap.put(4, E);
    letMap.put(5, F);
    letMap.put(6, G);
    letMap.put(7, H);
    letMap.put(8, I);
    letMap.put(9, J);
    letMap.put(10, K);
    letMap.put(11, L);
    letMap.put(12, M);
    letMap.put(13, N);
    letMap.put(14, O);
    letMap.put(15, P);
    letMap.put(16, Q);
    letMap.put(17, R);
    letMap.put(18, S);
    letMap.put(19, T);
    letMap.put(20, U);
    letMap.put(21, V);
    letMap.put(22, W);
    letMap.put(23, X);
    letMap.put(24, Y);
    letMap.put(25, Z);
    return letMap;
  }

  public void Output(ArrayList<String> tempList, HashMap<Integer, ArrayList<String>> letMap, HashMap<String, Integer> NumTrans){
    String line1 = "";
    String line2 = "";
    String line3 = "";
    String line4 = "";
    String line5 = "";
    ArrayList<String> List = new ArrayList<String>();
    for(int i = 0; i < tempList.size(); i++){
      String tempString = tempList.get(i); //line 325-327 converts indidual characters of input into list of strings per letter
      Integer tempInt = NumTrans.get(tempString);
      List = letMap.get(tempInt); // List is an arraylist of the CURRENT character of the loop
      line1 = line1 + List.get(0); //returns first string of letter
      line2 = line2 + List.get(1); //Idea, create list of ArrayList of Arraylist of the strings of each 5 lines letter, to call upon each one as a parameter within the curent. ok gn fam
      line3 = line3 + List.get(2);
      line4 = line4 + List.get(3);
      line5 = line5 + List.get(4);
    }

    System.out.println(line1);
    System.out.println(line2);
    System.out.println(line3);
    System.out.println(line4);
    System.out.println(line5);
  }

}
